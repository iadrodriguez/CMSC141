import java.io.*;
import java.util.ArrayList;
import java.util.Scanner;

public class Tester {

    public static String getInputFile() {
        System.out.print("Enter a valid name of input file [It would be better if the input file and the source codes are in the same folder]: ");
        Scanner sc = new Scanner(System.in);
        return sc.next();
    }

    public static void main(String[] args) {
        String fileIn = "";
        String fileOut = "rodriguez1.out";

        boolean right = false;
        while (right == false) {
            String file = getInputFile();
            try {
                BufferedReader br = new BufferedReader(new FileReader(file));
                right = true;
                fileIn = file;
            } catch (FileNotFoundException e) {
                right = false;
            }
        }

        Paparazzi paparazzi = new Paparazzi(fileIn, fileOut);
        ArrayList<Testcase> ins = paparazzi.prepareTestcase();
            BufferedWriter bw = null;

            try {
                bw = new BufferedWriter(new FileWriter(new File(fileOut)));
                int ctr = 1;
                for (int i = 0; i < ins.size(); i++) {
                    Testcase in = ins.get(i);
                    bw.append(paparazzi.validity(in) + " " + paparazzi.typ(in.getType()));
                    bw.newLine();
                    ctr++;
                    System.out.println();
                }
            } catch (IOException e) {
                e.printStackTrace();
            } finally {
                try {
                    if (bw != null) {
                        bw.close();
                    }
                } catch (IOException ex) {
                    ex.printStackTrace();
                }
            }
        }
}
