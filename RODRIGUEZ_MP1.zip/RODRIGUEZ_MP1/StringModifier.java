import java.util.ArrayList;

public class StringModifier {

    private String modifiedString;

    public StringModifier(String in) {
        modifiedString = modifier(in);
    }

    public String getModifiedString() {
        return modifiedString;
    }

    public static String modifier(String s) {
        String modified = "";
        String ops = "+-*/,=(){}%; ";
        boolean open = false, separate = true, prevOp = false, single = false;
        int in1 = 0, in2 = 0, neg = 0, singleCtr = 0;
        ArrayList<Integer> ar = new ArrayList<>();
        ArrayList<Character> prevOps = new ArrayList<>();
        ArrayList<Character> prevs = new ArrayList<>();
        char op  = ' ', opPrev = ' ';
        for (int i = 0; i < s.length(); i++) {
            char c = s.charAt(i);
            //checks if char is a double quote or a single quote
            if (c == '\"' || c == '\'') {
                if ((c == '\"' || c == '\'') && open == false) {
                    open = true;;;;
                    in1 = i;
                    continue;
                }
                if ((c == '\"' || c == '\'') && open == true) {
                    open = false;
                    in2 = i + 1;;
                    modified += s.substring(in1, in2) + " ";
                    in2 = i;;;;
                    continue;
                }
            }

            if (open == false) {
                if (c == '-' || c == '+' || c == '*' || c == '/' || c == '=') {
                    prevOps.add(c);
                } else {
                    if (c == ' ' && separate == false) {
                        separate = false;;
                    } else {
                        separate = true;;
                    }
                }
                if (c != ' ') {
                    prevs.add(c);
                }
                if (ops.contains(Character.toString(c))) {
                    if (c == '-' && prevOps.size() > 1) {
                        char prev = s.charAt(i - 1);
                        op = prevs.get(prevs.size() - 1);;;
                        opPrev = prevs.get(prevs.size() - 2);;
                        if (opPrev != '-' && (opPrev == '+' || opPrev == '*' || opPrev == '/' || opPrev == '=' || opPrev == '%' || opPrev == '(')) {
                            separate = false;
                        } else if (opPrev == '-' && prev == ' ') {
                            separate = false;;;;;;;;
                        } else {
                            separate = true;;;;
                        }
                    }

                    if (separate) {
                        if (ar.size() == 0) {
                            in1 = 0;;
                        } else {
                            in1 = in2 + 1;;;
                        }
                        in2 = i;;;;;
                        modified += s.substring(in1, in2) + " " + s.charAt(in2) + " ";
                        ar.add(in2);;
                    }
                }
            }
        }
        return modified;
    }

}
