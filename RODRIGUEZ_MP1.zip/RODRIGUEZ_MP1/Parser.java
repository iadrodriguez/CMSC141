import java.io.BufferedReader;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.util.ArrayList;

public class Parser {

    private String filename;
    private ArrayList<ArrayList<String>> extracted = new ArrayList<ArrayList<String>>();
    private ArrayList<String> allTestCase = new ArrayList<String>();
    private static int testCases;

    public Parser(String fn) {
        filename = fn;
        extracted = fileReader(filename);
        allTestCase = asOneTestCase(extracted, testCases);
    }

    public void setFilename(String f) {
        filename = f;
    }

    public ArrayList<String> getAllTestCase() {
        return allTestCase;
    }

    private static ArrayList<ArrayList<String>> fileReader(String filename) {
        BufferedReader br = null;
        FileReader fr = null;
        ArrayList<ArrayList<String>> lines = new ArrayList<ArrayList<String>>();
        ArrayList<String> perLine = new ArrayList<String>();
        boolean newList = false;
        boolean foundOpenCurly = false;
        boolean foundSemi = false;
        boolean isFunctionDef = false;
        boolean goToElse = false;
        boolean addedWithOpen = false, openPara = false, skipCheck = false, firstCurly = false;

        try {
            try {
                br = new BufferedReader(new FileReader(filename));
            } catch (FileNotFoundException e) {
                e.printStackTrace();
            }
            String sCurrentLine;
            try {
                testCases = Integer.valueOf(br.readLine());
                while ((sCurrentLine = br.readLine()) != null) {
                    int curlyIndex = -1;
                    foundSemi = false;
                    goToElse = false;
                    skipCheck = false;
                    openPara = false;
                    firstCurly = false;
                    String trimmed = sCurrentLine;
                    trimmed = trimmed.trim(); //remove leading and trailing white spaces
                    if(trimmed.contains(";")) {
                        if (trimmed.endsWith("}") && !trimmed.contains("{")) {
                            goToElse = true;
                        }
                        if (!goToElse) {
                            boolean singleOpen = false,
                                    singleClose = false,
                                    doubleOpen = false,
                                    doubleClose = false,
                                    separate = true;
                            foundSemi = true;
                            ArrayList<Integer> indexes = new ArrayList<Integer>();
                            for (int i = 0; i < trimmed.length(); i++) {
                                if (trimmed.charAt(i) == '{') {
                                    curlyIndex = i;
                                    openPara = true;
                                    if(indexes.isEmpty()){
                                        firstCurly = true;
                                    }
                                }
                                if (curlyIndex == -1) {
                                    if (trimmed.charAt(i) == ';') {
                                        if (i <= trimmed.length() - 2) {
                                            if (trimmed.charAt(i + 1) == '"'
                                                    || trimmed.charAt(i + 1) == '\'' || trimmed.charAt(i + 1) == ';') {
                                            } else {
                                                singleOpen = trimmed.substring(0, i + 1).contains("'");
                                                singleClose = trimmed.substring(i + 1).contains("'");
                                                doubleOpen = trimmed.substring(0, i + 1).contains("\"");
                                                doubleClose = trimmed.substring(i + 1).contains("\"");
                                                if (singleOpen && singleClose) {
                                                    separate = false;
                                                }
                                                if (doubleOpen && doubleClose) {
                                                    separate = false;
                                                }
                                                if (separate) {
                                                    if (!indexes.contains(i + 1)) {
                                                        indexes.add(i + 1);
                                                    }
                                                }
                                            }

                                        }
                                    }
                                    if (i == trimmed.length() - 1) {
                                        if (!indexes.contains(i + 1)) {
                                            indexes.add(i + 1);
                                        }
                                    }
                                }
                            }
                            if(!indexes.isEmpty()) {
                                if (indexes.size() == 1) {
                                    if (indexes.get(0).equals(trimmed.length())) {
                                        perLine.add(trimmed);
                                        if (!foundOpenCurly) {
                                            lines.add(perLine);
                                            perLine = new ArrayList<String>();
                                        }
                                    } else {
                                        String sub = trimmed.substring(0, indexes.get(0)).trim();
                                        perLine.add(sub);
                                        lines.add(perLine);
                                        perLine = new ArrayList<String>();
                                        if (openPara) {
                                            sub = trimmed.substring(indexes.get(0)).trim();
                                            perLine.add(sub);
                                            openPara = false;
                                            foundOpenCurly = true;
                                            if (sub.endsWith("}")) {
                                                lines.add(perLine);
                                                perLine = new ArrayList<String>();
                                                skipCheck = true;
                                                openPara = foundOpenCurly = false;
                                            }
                                        }
                                    }

                                } else {
                                    String subs = "";
                                    for (int j = 0; j < indexes.size(); j++) {
                                        if (j == 0) {
                                            subs = trimmed.substring(0, indexes.get(j)).trim();
                                            perLine.add(subs);
                                            if (!foundOpenCurly) {
                                                lines.add(perLine);
                                                perLine = new ArrayList<String>();
                                            }
                                        } else if (j == (indexes.size() - 1)) {
                                            if (indexes.get(j).equals(trimmed.length())) {
                                                subs = trimmed.substring(indexes.get(j - 1)).trim();
                                                perLine.add(subs);
                                                if (!foundOpenCurly) {
                                                    lines.add(perLine);
                                                    perLine = new ArrayList<String>();
                                                }
                                                if (openPara) {
                                                    subs = trimmed.substring(indexes.get(j)).trim();
                                                    foundOpenCurly = true;
                                                    perLine.add(subs);
                                                    openPara = false;
                                                    foundOpenCurly = true;
                                                    if (subs.endsWith("}")) {
                                                        lines.add(perLine);
                                                        perLine = new ArrayList<String>();
                                                        skipCheck = true;
                                                        openPara = foundOpenCurly = false;
                                                    }
                                                }

                                            } else {
                                                if (openPara) {
                                                    subs = trimmed.substring(indexes.get(j - 1), indexes.get(j)).trim();
                                                    perLine.add(subs);
                                                    lines.add(perLine);
                                                    perLine = new ArrayList<String>();
                                                    subs = trimmed.substring(indexes.get(j)).trim();
                                                    perLine.add(subs);
                                                    openPara = false;
                                                    foundOpenCurly = true;
                                                    if (subs.endsWith("}")) {
                                                        //         System.out.println("lol");
                                                        if (!perLine.equals(null)) {
                                                            lines.add(perLine);
                                                            perLine = new ArrayList<String>();
                                                        }
                                                        foundOpenCurly = openPara = false;
                                                        skipCheck = true;
                                                    }
                                                } else {
                                                    subs = trimmed.substring(indexes.get(j)).trim();
                                                    perLine.add(subs);
                                                }
                                            }
                                        } else {
                                            subs = trimmed.substring(indexes.get(j - 1), indexes.get(j)).trim();
                                            perLine.add(subs);
                                            if (!foundOpenCurly) {
                                                lines.add(perLine);
                                                perLine = new ArrayList<String>();
                                            }
                                        }
                                    }
                                }
                            }
                        }
                    }
                    else if (trimmed.contains("{") && !foundOpenCurly) { //if there is open curly, same arraylist
                        foundOpenCurly = true;
                        if (!trimmed.endsWith("}")) {
                            perLine.add(trimmed);
                            addedWithOpen = true;
                        }
                    }

                    else if(!foundSemi && !trimmed.endsWith("}")){
                        perLine.add(trimmed);
                    }

                    if(!skipCheck) {
                        if (trimmed.endsWith("}")) { //if there is closed curly, signal for new arraylist
                            foundOpenCurly = false;
                            openPara = firstCurly = false;
                            perLine.add(trimmed);
                            lines.add(perLine);
                            perLine = new ArrayList<String>();
                        }
                    }
                    if(openPara && firstCurly){
                        perLine.add(trimmed);
                        if(trimmed.endsWith("}")) {
                            lines.add(perLine);
                            perLine = new ArrayList<String>();
                            foundOpenCurly = false;
                        }
                        else{
                            foundOpenCurly = true;
                        }
                    }
                }
                if(foundOpenCurly || !perLine.isEmpty()){
                    lines.add(perLine);
                    perLine = new ArrayList<>();
                }

            } catch (IOException e1) {
                e1.printStackTrace();
            }

        } finally {
            try {

                if (br != null)
                    br.close();

                if (fr != null)
                    fr.close();

            } catch (IOException ex) {
                ex.printStackTrace();

            }
        }
        return lines;
    }


    public static ArrayList<String> asOneTestCase(ArrayList<ArrayList<String>> arlist, int testcases){
        ArrayList<String> result = new ArrayList<String>();
        String modified;
        if(arlist.size() == testcases){

        }
        for (int i = 0; i < arlist.size(); i++) {
            modified = "";
            if (arlist.get(i).size() == 1) {
                result.add(arlist.get(i).get(0));
            } else {
                for (int j = 0; j < arlist.get(i).size(); j++) {
                    modified += arlist.get(i).get(j) + " ";
                }
                result.add(modified.trim());
            }
        }
        return result;
    }
}
