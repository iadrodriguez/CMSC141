import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

/*
=-=-=-=-=-=-==-=-=-=-=-=-=-=-=-=-=-=-=-=-=-CMSC 141 MP1 (Paprazzi, Grammar Nazi)=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=
Collaborators:
	Arsolon, Lovely Grace
	Pacana, Michael Ervin
	Rodriguez, Icel Ann
	Salera, Marie Curie

Resources used in doing this Machine Problem:
	1) States
		Below is the state table wherein it checks what next states are valid for the current state. This is
		derived from the previous Machine Problem in CMSC 21, MPA 6(Gatekeepers of 244).

						STATES													VALID STATES
	   ______________________________________________________________________________________________________________
		1) Type														Variable name, Comma, Semicolon, Closing
																	Parenthesis (if open parenthesis == true)

		2) Variable Name (_ + alphanumeric character)				Open parenthesis, operators, comma,
																	semicolon

		3) Numeric Characters										Closing Parenthesis (if open parenthesis
		   Strings with ("") or ('')								== true), Semicolon, Operators, Comma

		4) Comma 													Numeric Characters | Strings with ("") or
																	(''), Type (if the state history has 2, 7, 1),
																	Variable Name

		5) Semicolon 												Type, Semicolon, Closed curly (if open curly ==
																	true), ==end==

		6) Operations ( + - / * % = )								Variable Name, Numeric Characters | Strings with
																	("") or (''), Open Parenthesis

		7) Open Parenthesis 										If function declaration:
																		Type
																	If variable declaration:
																		Variable Name, Numeric Characters

		8) Close Parenthesis 										Operators, Semicolon, Open Curly

		9) Open Curly 												Type, Return, Variable Name

		10) Closed Curly 											==end==

		11) Void													Variable name (should be function def
																	or function dec) Semicolon

		12) Return 													Numeric, Semicolon, Variable name
																	Open Parenthesis

	2) Reserved Keywords in C language
		https://beginnersbook.com/2014/01/c-keywords-reserved-words/

	3) StringTokenizer class (alternative to string.split())
		https://docs.oracle.com/javase/7/docs/api/java/util/StringTokenizer.html

	4) Online C Compiler && Code::Blocks
		https://www.onlinegdb.com/online_c_compiler
*/


public class Paparazzi {

    private String file_in, file_out;
    private static ArrayList<String> decVars;
    private static int openPar, closePar;
    private static int cParDec = -1;

    public Paparazzi(String in, String out) {
        file_in = in;
        file_out = out;
    }

    public String getFile_in() {
        return file_in;
    }

    public String getFile_out() {
        return file_out;
    }

    public ArrayList<Testcase> prepareTestcase() {
        ArrayList<Testcase> inputs = new ArrayList<>();
        Parser parseInputs = new Parser(file_in);
        ArrayList<String> testcases = parseInputs.getAllTestCase();
        for (int i = 0; i < testcases.size(); i++) {
            String str = testcases.get(i);
            StringModifier sm = new StringModifier(str + " ");
            Testcase in = new Testcase(sm.getModifiedString());
            inputs.add(in);
        }
        return inputs;
    }

    //TODO
    public static String validity(Testcase tc) {
        decVars = new ArrayList<>();
        openPar = 0;
        closePar = 0;
        ArrayList states = tc.getStates();
        boolean valid = true;
        int ctr = 1, type = tc.getType();
        if (!states.isEmpty()) {
            int curr = (int) states.get(0), next = 0, prev = 0;
            if ((int) states.get(0) != 1 && (int) states.get(0) != 11) {
                valid = false;
            } else {
                while (valid == true && ctr <= states.size()) {
                    if (tc.getType() == 3) {
                        if ((int) states.get(0) == 1) {
                            if (!states.contains(12)) {
                                valid = false;
                                break;
                            }
                        }
                    }
                    if (ctr == states.size()) {
                        next = 13;
                    } else {
                        next = (int) states.get(ctr);
                    }
                    valid = isValid2(prev, curr, next, tc, ctr);
                    prev = curr;
                    curr = next;
                    ctr++;
                }

                //check count of parenthesis
                if (valid) {
                    if (openPar != closePar) {
                        valid = false;
                    }
                }

                if (tc.getType() == 3) {
                    if (checkPar(tc) > 1) {
                        valid = false;
                    }
                }
            }
        }
        if (valid == true) {
            return "VALID";
        } else {
            return "INVALID";
        }
    }

    public static int checkPar(Testcase tc) {
        int ct = 0, ctr = 0;
        while (!tc.getStates().get(ctr).equals(9)) {
            if (tc.getStates().get(ctr).equals(7)) {
                ct++;
            }
            ctr++;
        }
        return ct;
    }

    public static boolean isValid2(int prev, int curr, int next, Testcase tc, int index) {
        if (curr == 1) {
            return validTypeNextState(prev, next, tc, index);
        } else if (curr == 2) {
            return validVarNameNextState(prev, next, tc, index);
        } else if (curr == 3) {
            return validOperandNextState(prev, next, tc, index);
        } else if (curr == 4) {
            return validCommaNextState(prev, next, tc, index);
        } else if (curr == 5) {
            return validSemicolonNextState(prev, next, tc, index);
        } else if (curr == 6) {
            return validOperatorNextState(prev, next, tc, index);
        } else if (curr == 7) {
            openPar++;
            return validOpenParNextState(prev, next, tc, index);
        } else if (curr == 8) {
            closePar++;
            return validCloseParNextState(prev, next, tc, index);
        } else if (curr == 9) {
            return validOpenCurlyNextState(prev, next, tc, index);
        } else if (curr == 10) {
            return validCloseCurlyNextState(prev, next, tc, index);
        } else if (curr == 11) {
            return validVoidNextState(prev, next, tc, index);
        } else if (curr == 12) {
            return validReturnNextState(prev, next, tc, index);
        }
        return false;
    }

    //1
    public static boolean validTypeNextState(int prev, int next, Testcase tc, int index) {
        if (tc.getType() == 3) {
            if (next == 2) {
                return true;
            }
        } else {
            if (next == 2 || next == 4 || next == 8 || next == 5) {
                return true;
            }
        }
        return false;
    }

    public static boolean check(ArrayList s, int in) {
        boolean valid = false;
        int ctr = in, prev = 0;
        while (ctr >= 1) {
            prev = ctr - 1;
            if ((int) s.get(prev) == 9 || (int) s.get(prev) == 7 ||  (int) s.get(prev) == 5) {
                valid = false;
                break;
            } else if ((int) s.get(prev) == 1) {
                valid = true;
                break;
            }
            ctr--;
        }
        return valid;
    }

    public static int indexOfCurly(ArrayList s) {
        int index = 0;
        for (int i = 0; i < s.size(); i++) {
            if ((int) s.get(i) == 9) {
                index = i;
                break;
            }
        }
        return index;
    }

    //2
    public static boolean validVarNameNextState(int prev, int next, Testcase tc, int index) {
        boolean ans = false;
        if (prev == 1) {
            if (next==6) {
                if (!tc.getTokens().get(index).equals("=")) {
                    return false;
                }
            }
        }
        if (tc.getType() == 3 || tc.getType() == 1) {
            if (prev == 1 || prev == 11) {
                if ((decVars.size() == 0) || (decVars.size() > 0 && !decVars.contains(tc.getTokens().get(index - 1)))) {
                    decVars.add(tc.getTokens().get(index - 1));
                    if (next == 7 || next == 6 || next == 4 || next == 5 || next == 8) {
                        if (next == 6) {
                            if (prev == 1) {
                                if (tc.getTokens().get(index).equals("=")) {
                                    return true;
                                }
                            }
                        } else {
                            return true;
                        }
                    }
                } else {
                    int latestIndex1 = 0;
                    if (tc.getType() == 3) {
                        for (int i = 0; i < (index-1); i++) {
                            if (tc.getStates().get(i) == 2) {
                                if (tc.getTokens().get(index-1).equals(tc.getTokens().get(i))) {
                                    latestIndex1 = i;
                                }
                            }
                        }
                        if(latestIndex1 > 1) {
                            return false;
                        } else {
                            if (next == 7 || next == 6 || next == 4 || next == 5 || next == 8) {
                                if (next == 6){
                                    if (prev == 1) {
                                        if (tc.getTokens().get(index).equals("=")) {
                                            return true;
                                        }
                                    }
                                } else {
                                    return true;
                                }
                            }
                        }
                    }

                }
            } else {
                if ((index - 1) < indexOfCurly(tc.getStates())) {
                    return false;
                } else {
                    boolean valid2 = false;
                    if ((decVars.size() > 0 && decVars.contains(tc.getTokens().get(index - 1)))) {
                        int latestIndex = 0;
                        if (tc.getType() == 3) {
                            for (int i = 0; i < (index-1); i++) {
                                if (tc.getStates().get(i) == 2) {
                                    if (tc.getTokens().get(index-1).equals(tc.getTokens().get(i))) {
                                        latestIndex = i;
                                    }
                                }
                            }
                            if (latestIndex == 1) {
                                return false;
                            }
                        }
                        if (prev == 6 || check(tc.getStates(), index - 1) == false) {
                            if (prev == 6) {
                                if (next == 7 || next == 6 || next == 4 || next == 5 || next == 8) {
                                    valid2 = true;
                                }
                            }
                            if (check(tc.getStates(), index - 1) == false) {
                                if (next == 7 || next == 6 || next == 4 || next == 5 || next == 8) {
                                    valid2 = true;
                                }
                            }
                            return valid2;
                        } else {
                            int p = (index - 1) - 1;
                            while (tc.getStates().get(p) != 9 || tc.getStates().get(p) != 7 || tc.getStates().get(p) != 5) {
                                if (tc.getStates().get(p) == 1 || (tc.getTokens().get(p).equals(tc.getTokens().get(index-1)) && tc.getStates().get(p - 1) != 6)) {
                                    return false;
                                }
                                p--;
                            }
                        }
                    } else {
                        if (tc.getType() == 1) {
                            if (next == 7 || next == 6 || next == 4 || next == 5 || next == 8) {
                                if (next == 6) {
                                    if (prev == 4) {
                                        if (tc.getTokens().get(index).equals("=")) {
                                            return true;
                                        }
                                    } else if (tc.getTokens().get(index-2).equals("=")) {
                                        if (!tc.getTokens().get(index).equals("=")) {
                                            return true;
                                        }
                                    }
                                } else {
                                    return true;
                                }
                            }
                        } else {
                            if (prev == 4) {
                                if (check(tc.getStates(), index - 1) == true) {
                                    if (next == 7 || next == 6 || next == 4 || next == 5 || next == 8) {
                                        if (next == 6) {
                                            if (tc.getTokens().get(index).equals("=")) {
                                                return true;
                                            }
                                        } else {
                                            return true;
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
            }
        } else {
            if (prev == 1) {
                if ((decVars.size() == 0) || (decVars.size() > 0 && !decVars.contains(tc.getTokens().get(index - 1)))) {
                    decVars.add(tc.getTokens().get(index - 1));
                    if (next == 7 || next == 6 || next == 4 || next == 5 || next == 8) {
                        return true;
                    }
                } else {
                    int latestIndex1 = 0;
                    for (int i = 0; i < (index - 1); i++) {
                        if (tc.getStates().get(i) == 2) {
                            if (tc.getTokens().get(index - 1).equals(tc.getTokens().get(i))) {
                                latestIndex1 = i;
                            }
                        }
                    }
                    if (latestIndex1 > 1) {
                        return false;
                    } else {
                        if (next == 7 || next == 6 || next == 4 || next == 5 || next == 8) {
                            return true;
                        }
                    }
                }
            } else {
                if (next == 7) {
                    return true;
                }
            }
        }
        return false;
    }

    //3
    public static boolean validOperandNextState(int prev, int next, Testcase tc, int index) {
        boolean ans = false;
        if (tc.getTokens().get(index-1).charAt(0) == '\'' && tc.getTokens().get(index-1).charAt(tc.getTokens().get(index-1).length() - 1) == '\'') {
            if (tc.getTokens().get(index-1).length() == 3) {
                if (next == 5 || next == 6 || next == 4 || next == 8) {
                    return true;
                }
            } else {
                return false;
            }
        }

        if (next == 5 || next == 6 || next == 4 || next == 8) {
            return true;
        }
        return false;
    }

    //4
    public static boolean validCommaNextState(int prev, int next, Testcase tc, int index) {
        boolean ans = false;
        if (tc.getType() == 2) {
            if (next == 2) {
                if (tc.getStates().get(index + 1) == 7) {
                    decVars.clear();
                    decVars = new ArrayList<>();
                    cParDec = -1;
                    return true;
                }
            } else if (next == 1) {
                if (prev == 8) {
                    return false;
                } else {
                    return true;
                }
            }
        } else if (tc.getType() == 1) {
            if (next == 2) { //next == 3 ||
                return true;
            }
        } else {
            if ((index - 1) > indexOfCurly(tc.getStates())) {
                if (next == 2) {
                    return true;
                }
            } else {
                if (next == 2 || next == 1) {
                    return true;
                }
            }
        }
        return false;
    }

    //5
    public static boolean validSemicolonNextState(int prev, int next, Testcase tc, int index) {
        boolean ans = false;
        if (next == 1 || next == 2 || next == 5 || next == 10 || next == 12 || next == 13) {
            return true;
        }
        return false;
    }

    //6
    public static boolean validOperatorNextState(int prev, int next, Testcase tc, int index) {
        boolean ans = false;
        if (tc.getType() == 2) {
            return false;
        } else {
            if (next == 2 || next == 3 || next == 7) {
                return true;
            }
        }
        return false;
    }

    //7
    public static boolean validOpenParNextState(int prev, int next, Testcase tc, int index) {
        boolean ans = false;
        if (tc.getType() == 1) {
            if (next == 2 || next == 3 || next == 7) {
                return true;
            }
        } else if (tc.getType() == 2 || tc.getType() == 3) {
            //added
            if (tc.getType() == 2) {
                if (cParDec == -1) {
                    cParDec = (index - 1);
                } else {
                    if ((index - 1) > cParDec) {
                        return false;
                    }
                }
            }

            if (tc.getType() == 3) {
                if (prev == 2) {
                    if ((index - 1) > indexOfCurly(tc.getStates())) {
                        return false;
                    }
                }
            }

            if (next == 3) {
                if (prev == 6 || prev == 7 || prev == 12 || prev == 9) {
                    return true;
                }
            } else if (next == 7) {
                if (prev == 9 || prev == 6 || prev == 12) {
                    return true;
                }
            } else if (next == 1) {
                if (prev != 9) {
                    return true;
                }
            } else if (next == 8) {
                return true;
            } else if (next == 2) {
                if (prev != 1 && prev != 2 && prev != 3) {
                    return true;
                }
            }
        }
        return false;
    }

    //8
    public static boolean validCloseParNextState(int prev, int next, Testcase tc, int index) {
        if (tc.getType() == 2 && next == 9) {
            return false;
        }
        if (next == 6 || next == 5 || next == 4 || next == 9 || next == 8) {
            return true;
        }
        return false;
    }

    //9
    public static boolean validOpenCurlyNextState(int prev, int next, Testcase tc, int index) {
        boolean ans = false;
        if (next == 1 || next == 12 || next == 2 || next == 10 || next == 7) {
            return true;
        }
        return false;
    }

    //10
    public static boolean validCloseCurlyNextState(int prev, int next, Testcase tc, int index) {
        boolean ans = false;
        //nothing's next
        if (next == 13) {
            return true;
        }
        return false;
    }

    //11
    public static boolean validVoidNextState(int prev, int next, Testcase tc, int index) {
        boolean ans = false;
        if (tc.getType() == 2) {
            if (index - 1 == 0) {
                if (next == 2) {
                    return true;
                }
            } else {
                if (next == 5 || next == 8) {
                    return true;
                }
            }
        } else if (tc.getType() == 3) {
            //should check if no return
            if (index - 1 == 0) {
                if (next == 2) {
                    return true;
                }
            } else {

            }
        }
        return false;
    }

    //12
    public static boolean validReturnNextState(int prev, int next, Testcase tc, int index) {
        boolean ans = false;
        //check it it has void in states
        if (!tc.getStates().contains(11)) {
            if (next == 3 || next == 2 || next == 7) {
                return true;
            }
        } else {
            if (next == 5) {
                return true;
            }
        }
        return false;
    }

    public static String typ(int t) {
        String ans = "";
        switch (t) {
            case 1:
                ans = "VARIABLE DECLARATION";
                break;
            case 2:
                ans = "FUNCTION DECLARATION";
                break;
            case 3:
                ans = "FUNCTION DEFINITION";
                break;
            default:

        }
        return ans;
    }

}