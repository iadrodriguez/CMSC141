import java.lang.reflect.Array;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.StringTokenizer;

public class Testcase {

    private int type;
    private ArrayList<String> tokens;
    private ArrayList<Integer> states;
    private ArrayList<String> declaredVars;

    //constructor
    public Testcase(String str) {
        tokens = new ArrayList<String>();
        states = new ArrayList<Integer>();
        declaredVars = new ArrayList<String>();
        tokenize(str);
        deterStates();
        determineType();
        determineDecVars();
    }

    public int getType() {
        return type;
    }

    public ArrayList<String> getTokens() {
        return tokens;
    }

    public ArrayList<Integer> getStates() {
        return states;
    }

    public ArrayList<String> getDeclaredVars() {
        return declaredVars;
    }

    public void determineDecVars() {
        if (!states.isEmpty()) {
            int prev = states.get(0);
            for (int i = 1; i < states.size(); i++) {
                int s = states.get(i);
                if (s == 2 && prev == 1) {
                    if (!declaredVars.contains(tokens.get(i))) {
                        declaredVars.add(tokens.get(i));
                    }
                }
                prev = s;
            }
        }
    }

    public void tokenize(String s) {
        StringTokenizer str = new StringTokenizer(s);
        while (str.hasMoreTokens()){
            tokens.add(str.nextToken());
        }
    }

    /*******************************DETERMINE TYPE***************************************/

    public int determineType() {
        boolean firstVarNameExist = false;
        int openParenState = 7, varNameState = 2;
        int statesSize = states.size(), cntr = 0;
    	/*Look for first occurence of variable name*/
        while (cntr < statesSize) {
            if(states.get(cntr) == varNameState) {
                firstVarNameExist = true;
                break;
            }
            cntr++;
        }
        if(firstVarNameExist == true) {
        	/*check if next to first variable name is not parenthesis*/
            if(states.get(cntr + 1) != openParenState) {
                if (!firstVarNameAftrOpenPar(cntr)) {
                    type = 1;
                }
                else if((firstVarNameAftrOpenPar(cntr) && isFuncDef()) || firstVarNameAftrOpenCurly(cntr)) {
                    type = 3;
                } else if (firstVarNameAftrOpenPar(cntr) && firstVarNameWithinParOnly(cntr)) {
                    type = 1;
                } else if (firstVarNameAftrOpenPar(cntr)) {
                    type = 2;
                }
            }
            /*check if many openPar before curly brace, error is invalid function declaration*/
            else if (((states.get(cntr + 1) == openParenState) && moreThanOneFunc()) /*&& oneOpenParOnlyB4Curly()*/) {
                type = 2;
            }
            /*check if first var name's next is open parenthesis && is func def*/
            else if ((states.get(cntr + 1) == openParenState) && isFuncDef()) {
                type = 3;
            }
            /*check if first var name is after open parenthesis && is func dec*/
            else if ((states.get(cntr + 1) == openParenState)) {
                type = 2;
            }
            else if (isFuncDef()) {
                type = 3;
            } else if (isFuncDec()) {
                type = 2;
            }
        } else if (isFuncDef()){
            type = 3;
        } else if (isFuncDec()) {
            type = 2;
        } else {
            type = 1;
        }
        return type;
    }

    public boolean firstVarNameWithinParOnly(int varNameInd) {
        boolean firstVarWthnParOnly = false;
        int noOpenPar = 0, noClosePar = 0,
                openParInd = varNameInd - 1, closeParInd = varNameInd + 1;
    	/*next lines will be used if ex: int (main)) = variable name;*/
        if(states.get(openParInd) == 7 && states.get(closeParInd) == 8) {
            firstVarWthnParOnly = true;
        }
        return firstVarWthnParOnly;
    }

    public boolean moreThanOneFunc(){
        boolean moreThan1Func = false, openCurlyExist = false;
        int indOpenCurly = 0, ctrToOpenCurly = 0;

        if (states.contains(9)) {
            openCurlyExist = true;
    		/*getIndexOpenCurly*/
            while (states.get(indOpenCurly) != 9 && indOpenCurly < states.size()) {
                indOpenCurly++;
            }
        }
        int openPar = 0;
        int closePar = 0;
        boolean hasPassedOpenPar = false, toExpectNewFunc = false;

        if (openCurlyExist) {
            while (ctrToOpenCurly < indOpenCurly) {
    			/*Finding for first function name with open par*/
                if (toExpectNewFunc == false) {
                    if (states.get(ctrToOpenCurly) == 2 && states.get(ctrToOpenCurly + 1) == 7) {
                        openPar += 1;
                        hasPassedOpenPar = true;
                    }
                    if (states.get(ctrToOpenCurly) == 8) {
                        closePar += 1;
                    }
                    if (hasPassedOpenPar) {
                        if (openPar == closePar) {
                            toExpectNewFunc = true;
                        }
                    }
                }
    			/*To expect for second function name with open par next to it*/
                else {
                    if (states.get(ctrToOpenCurly) == 2 && states.get(ctrToOpenCurly + 1) == 7) {
                        moreThan1Func = true;
                        break;
                    }
                }
                ctrToOpenCurly++;
            }
        }
        return moreThan1Func;
    }

    public boolean firstVarNameAftrOpenPar(int firstVarNameIn) {
        boolean firstVarAfterOP = false;
        int cntr = firstVarNameIn;
    	/*checking if first var name exist after open parenthesis*/
        while (cntr >= 0) {
            if (states.get(cntr) == 7) {
                firstVarAfterOP = true;
                break;
            }
            cntr--;
        }
        return firstVarAfterOP;
    }

    public boolean firstVarNameAftrOpenCurly(int firstVarNameIn) {
        boolean firstVarAfterOC = false;
        int cntr = firstVarNameIn;
    	/*checking if first var name exist after open curly*/
        while (cntr >= 0) {
            if (states.get(cntr) == 9) {
                firstVarAfterOC = true;
                break;
            }
            cntr--;
        }
        return firstVarAfterOC;
    }


    public int firstVarNameAftrOpenParType(int firstVarNameIn) {
        int type = 1;
        int cntr = firstVarNameIn;
        boolean firstVarAfterOP = false;
    	/*checking if first var name exist after open parenthesis*/
        while (cntr >= 0) {
            if (states.get(cntr) == 7) {
                firstVarAfterOP = true;
                break;
            }
            cntr--;
        }
        if (firstVarAfterOP) {
            if (openCurlyFindIndex() > 0) {
                type = 3;
            } else {
                type = 2;
            }
        }
        return type;
    }

    public boolean isFuncDef() {
  	  /*FUNCTION DEFINITION is true if 'open-curly-brace-state' exist in the arraylist and no operator exist before it*/
        boolean openCurlyExist = false, operationExistBeforeOpenPar = false, isFuncDefi = false;

        int statesSize = states.size(), operationState = 6;
        int openCurlyIndex = openCurlyFindIndex();
        int openParIndex = openParenFindIndex();
        if (openCurlyIndex < statesSize) {
            openCurlyExist = true;
        }

        if (openCurlyExist) {
        	/*Check if any operation exist before '('*/
            for (int i = 0; i < openParIndex; i++) {
            	/*check if operation exist before '('*/
                if ( states.get(i) == operationState) {
                    operationExistBeforeOpenPar = true;
                }
            }
        }

	  /*Check if opencurlyExist and no operation exist before openPar*/
        if (openCurlyExist && !operationExistBeforeOpenPar){
            isFuncDefi = true;
        }
        return  isFuncDefi;

    }

    public int openCurlyFindIndex() {
        int openCurlyState = 9; /* flag value of open curly*/
        int statesSize = states.size(); /*or no of tokens*/
        int cntr = 0;

	  /*check location of '{'*/
        while (cntr < statesSize) {
            int curState = states.get(cntr);
            if (curState == openCurlyState) {
                break;
            }
            cntr++;
        }
        return cntr;
    }

    public boolean isFuncDec() {
		/*FUNCTION DECLARATION is true if 'open-parenthesis-state' exist in the arraylist and no operator exist before it*/
        boolean openParenExist = false, operationExist = false, isFuncDecl = false;

        int statesSize = states.size(), operationState = 6;
        int openParenIndex = openParenFindIndex();
        if (openParenIndex < statesSize) {
            openParenExist = true;
        }

	  /*Check if any operation exist before '{'*/
        for (int i = 0; i < openParenIndex; i++) {
            if ( states.get(i) == operationState) {
                operationExist = true;
            }
        }
	  /*Check if opencurlyExist and no operation exist before it*/
        if (openParenExist && !operationExist) {
            isFuncDecl = true;
        }
        return  isFuncDecl;
    }

    public int openParenFindIndex() {
        int openParenState = 7; /* flag value of open curly*/
        int statesSize = states.size(); /*or no of tokens*/
        int cntr = 0;

	  /*check location of '{'*/
        while (cntr < statesSize) {
            int curState = states.get(cntr);
            cntr++;
            if (curState == openParenState) {
                break;
            }
        }
        return cntr;
    }
    //============================STATESSSS=====================================

    //determine the state of every token in a string array in each test case
    public void deterStates() {
//		ArrayList states = new ArrayList();
        for (int i = 0; i < tokens.size(); i++) {
            String s = tokens.get(i);
                if (isType(s)) {
                    states.add(1);
                }
                //variable name
                else if (isVarName(s) && !isOperand(s) && !s.equals(",") &&
                        !s.equals(";") && !isOperation(s) && !s.equals("(") &&
                        !s.equals(")") && !s.equals("{") && !s.equals("}") &&
                        !s.equals("void") && !s.equals("return")) {
                    states.add(2);
                }
                //operands
                else if (isOperand(s) && !s.equals(",") && !s.equals(";") && !isOperation(s) &&
                        !s.equals("(") && !s.equals(")") && !s.equals("{") && !s.equals("}") &&
                        !s.equals("void") && !s.equals("return")) {
                    states.add(3);
                }
                //comma
                else if (s.equals(",") && !s.equals(";") && !isOperation(s) &&
                        !s.equals("(") && !s.equals(")") && !s.equals("{") && !s.equals("}") &&
                        !s.equals("void") && !s.equals("return")) {
                    states.add(4);
                }
                //semicolon
                else if (s.equals(";") && !isOperation(s) && !s.equals("(") && !s.equals(")") &&
                        !s.equals("{") && !s.equals("}") && !s.equals("void") && !s.equals("return")) {
                    states.add(5);
                }
                //operator/operation
                else if (isOperation(s) && !s.equals("(") && !s.equals(")") && !s.equals("{") && !s.equals("}") &&
                        !s.equals("void") && !s.equals("return")) {
                    states.add(6);
                }
                //open parenthesis
                else if (s.equals("(") && !s.equals(")") && !s.equals("{") && !s.equals("}") &&
                        !s.equals("void") && !s.equals("return")) {
                    states.add(7);
                }
                //closed parenthesis
                else if (s.equals(")") && !s.equals("{") && !s.equals("}") && !s.equals("void") && !s.equals("return")) {
                    states.add(8);
                }
                //open curly brace
                else if (s.equals("{") && !s.equals("}") && !s.equals("void") && !s.equals("return")) {
                    states.add(9);
                }
                //closed curly brace
                else if (s.equals("}") && !s.equals("void") && !s.equals("return")) {
                    states.add(10);
                }
                //void type
                else if (s.equals("void") && !s.equals("return")) {
                    states.add(11);
                }
                //return statement
                else if (s.equals("return")) {
                    states.add(12);
                }
                else {
                    states.add(0);
                }
        }
    }

    public boolean isType(String type) {
        String[] typs = {"int", "char", "double", "float"};
        List<String> types = Arrays.asList(typs);
        boolean ans = false;
        if (types.contains(type)) {
            ans = true;
        }
        return ans;
    }

    public boolean isNumber(String s) {
        boolean isInt = false, isFloat = false;

        //checks if string is parsable into integer
        try {
            Integer.parseInt(s);
            isInt = true;
        } catch (NumberFormatException e) {
            isInt = false;
        }

        //checks if string is parsable into float
        try {
            Double.parseDouble(s);
            isFloat = true;
        } catch (NumberFormatException e) {
            isFloat = false;
        }

        if (isInt == true || isFloat == true) {
            return true;
        } else {
            return false;
        }
    }

    public boolean isStrChar(String s) {
        int in1 = 0, in2 = s.length() - 1;
        if ( ((Character.toString(s.charAt(in1)).equals("'")) &&
                (Character.toString(s.charAt(in2)).equals("'"))) ||
                (s.charAt(in1) == '"' && s.charAt(in2) == '"') ) {
            return true;
        }
        return false;
    }

    public boolean isSpe(String s) {
        for (int i = 0; i < s.length(); i++) {
            char c = s.charAt(i);
            if (c != '_' && !Character.isLetter(c) && !Character.isDigit(c)) {
                return true;
            }
        }
        return false;
    }

    public boolean isKeyword(String s) {
        if (s.equals("if") || s.equals("while") || s.equals("auto") ||
                s.equals("break") || s.equals("case") || s.equals("const") ||
                s.equals("continue") || s.equals("default") ||
                s.equals("do") || s.equals("short") || s.equals("long") ||
                s.equals("register") || s.equals("static") ||
                s.equals("struct") || s.equals("signed") || s.equals("sizeof") ||
                s.equals("typedef") || s.equals("void") || s.equals("volatile") ||
                s.equals("double") || s.equals("else") || s.equals("enum") ||
                s.equals("extern") || s.equals("for") || s.equals("goto")) {
            return true;
        }
        return false;
    }

    public boolean isVarName(String s) {
        boolean ans = false;
        String nums = "0123456789";
        if (isKeyword(s)) {
            return false;
        } else if ((Character.isDigit(s.charAt(0)) && !isNumber(s))) {
            return false;
        } else if (isSpe(s)) {
            return false;
        } else if (isNumber(s)) {
            return false;
        } else {
            ans = true;
        }
        return ans;
    }

    //determines if number(int, float) or (string, char)
    public boolean isOperand(String s) {
        if (isNumber(s) == true || isStrChar(s) == true) {
            return true;
        }
        return false;
    }

    public boolean isOperation(String s) {
        String ops = "+-/*=%";
        if (ops.contains(s)) {
            return true;
        }
        return false;
    }

    //============================STATESSSS==============================================
}